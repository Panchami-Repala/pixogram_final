import { Injectable } from '@angular/core';
import {Router}  from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedin = false;
  username:String;
  constructor(public router:Router) { }
change(){
  this.isLoggedin = true;

}
change1(){
  this.isLoggedin = false;
  this.router.navigate(['/']);

}


}
