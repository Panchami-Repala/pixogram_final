import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-update',
  templateUrl: './account-update.component.html',
  styleUrls: ['./account-update.component.css']
})
export class AccountUpdateComponent implements OnInit {

  constructor(public userService:UserService,public authService:AuthService,public router:Router) { 
  }
 
   ngOnInit() {
     if(!this.authService.isLoggedin)
     {
       this.router.navigate(['/']);
     }

}
}
