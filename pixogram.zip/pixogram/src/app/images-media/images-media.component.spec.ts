import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImagesMediaComponent } from './images-media.component';

describe('ImagesMediaComponent', () => {
  let component: ImagesMediaComponent;
  let fixture: ComponentFixture<ImagesMediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImagesMediaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImagesMediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
