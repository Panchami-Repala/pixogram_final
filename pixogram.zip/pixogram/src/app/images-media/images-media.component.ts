import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-images-media',
  templateUrl: './images-media.component.html',
  styleUrls: ['./images-media.component.css']
})
export class ImagesMediaComponent implements OnInit {

  constructor(public userService:UserService,public authService:AuthService,public router:Router) { 
  }
 
   ngOnInit() {
     if(!this.authService.isLoggedin)
     {
       this.router.navigate(['/']);
     }

}
}

