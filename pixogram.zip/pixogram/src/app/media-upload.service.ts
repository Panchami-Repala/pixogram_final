import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MediaUploadService {

  private baseUrl = 'http://localhost:8081';
  constructor(private http: HttpClient) { }

 uploadImage(img: Object): Observable<Object> {
   console.log("In service class");
    return this.http.post(`${this.baseUrl}` + `/image`,img);
   
  }

}
