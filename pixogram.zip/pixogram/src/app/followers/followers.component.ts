import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {

  constructor(public userService:UserService,public authService:AuthService,public router:Router) { 
  }
 
   ngOnInit() {
     if(!this.authService.isLoggedin)
     {
       this.router.navigate(['/']);
     }

}
}
