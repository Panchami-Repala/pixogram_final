
import { UserService } from '../user.service';
import {HttpClient} from '@angular/common/http';
import { OnInit, Component } from '@angular/core';
import { UploadImages } from '../models/uploadImages';
import {Router} from '@angular/router';
import { MediaUploadService } from '../media-upload.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-single-media-upload',
  templateUrl: './single-media-upload.component.html',
  styleUrls: ['./single-media-upload.component.css']
})
export class SingleMediaUploadComponent implements OnInit {
  
  
public image:File


  constructor(public userService:UserService,public http:HttpClient,public uploadMedia:MediaUploadService,public router:Router,public authService:AuthService) { }
  ngOnInit() {
    if(this.authService.isLoggedin==false)
        this.router.navigate(['/']);
  }
 
  fileChange(event: any) {
    // Instantiate an object to read the file content
    let reader = new FileReader();
    // when the load event is fired and the file not empty
    if(event.target.files && event.target.files.length > 0) {
      // Fill file variable with the file content
      this.image = event.target.files[0];
    }
  }

  onUpload() {
   // this.submitted = true;
    let user = new UploadImages(this.image);
    console.log("before calling service");
    this.uploadMedia.uploadImage(user)
    .subscribe(data => console.log(data), error => console.log(error));
    //this.userService.username=this.user_name;
    console.log("after calling service");
    this.router.navigate(['myMedia']);
  }

}