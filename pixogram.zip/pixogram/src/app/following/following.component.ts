import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-following',
  templateUrl: './following.component.html',
  styleUrls: ['./following.component.css']
})
export class FollowingComponent implements OnInit {

  constructor(public userService:UserService,public authService:AuthService,public router:Router) { 
  }
 
   ngOnInit() {
     if(!this.authService.isLoggedin)
     {
       this.router.navigate(['/']);
     }

}
}
