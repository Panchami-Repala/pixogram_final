import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import {UserService} from '../user.service';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user_name: String;
  password: String;
  invalidLogin: boolean = false;
  users: User[];

  constructor(private router: Router,public authService: AuthService,public userService:UserService) {

   }

  ngOnInit() {
    this.userService.getUsers().subscribe(response => this.users = response);
    
  }

  onLogin(){
    this.authService.change();
  }
  onLogout(){
    this.authService.change1();
  }
  onUserLogin(){
    for (let i = 0; i < this.users.length; i++) {
    // console.log(this.user_name);
    console.log(this.password);
      if (this.users[i].user_name === this.user_name && this.users[i].password === this.password) {
        
        console.log("hello");
        console.log(this.users[i].user_name);
        console.log(this.users[i].password);
        this.invalidLogin = false;
        this.router.navigate(['myMedia']);
        this.userService.username=this.users[i].user_name;
        this.userService.userId=this.users[i].id;
        this.onLogin();
       localStorage.setItem("userId", this.users[i].id.toString());
       break;
      } 
      else {
        
        
        this.invalidLogin = true;
        this.router.navigate(['login']);
      }


    }
  }

}