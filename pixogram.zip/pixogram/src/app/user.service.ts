import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import{HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  public username:String;
  public userId:number;

  private baseUrl = 'http://localhost:8081';
  constructor(private http: HttpClient) { }

  createUser(user: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/user/create`,user);
  }

  getUsers(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/user`);
  }

  createUserFollow(userf: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/userFollow/create`,userf);
  }

}
