import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { User } from '../models/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user_name: String;
  first_name: String;
  last_name: String;
  email: String;
  password: String;
  rPassword: String;
  profile_pic:File;
  submitted = false;
  error:boolean=false;
  constructor(private userService: UserService, private authService: AuthService,private router: Router) { }
  

  ngOnInit() {
    
    
  }
 
  register(){
    this.authService.change();
  }

  onSubmit() {
    this.submitted = true;
    let user = new User(this.first_name,this.last_name,this.user_name, this.email,this.password);
    this.userService.createUser(user)
    .subscribe(data =>
      {
      console.log(data);
      this.router.navigate(['login']);
      }, 
      error => {
        console.log(error)
        this.error=true;
      this.router.navigate(['register']);
      });
    this.userService.username=this.user_name;
  
    // if(!Error)
    //   this.router.navigate(['login']);
    // else
    // {
    //   this.error=true;
    //   this.router.navigate(['register']);
    // }
  }

}


