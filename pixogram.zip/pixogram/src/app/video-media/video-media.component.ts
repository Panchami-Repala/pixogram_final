import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-video-media',
  templateUrl: './video-media.component.html',
  styleUrls: ['./video-media.component.css']
})
export class VideoMediaComponent implements OnInit {

  constructor(public userService:UserService,public authService:AuthService,public router:Router) { 
  }
 
   ngOnInit() {
     if(!this.authService.isLoggedin)
     {
       this.router.navigate(['/']);
     }
   
 
   }
 
 }
 