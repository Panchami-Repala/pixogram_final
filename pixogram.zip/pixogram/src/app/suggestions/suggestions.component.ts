import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { FollowRequestService } from '../follow-request.service';
import { Follow } from '../models/follow';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-suggestions',
  templateUrl: './suggestions.component.html',
  styleUrls: ['./suggestions.component.css']
})
export class SuggestionsComponent implements OnInit {

  public users:User[];
  fid: number;
  followingId: number;
 
  
  constructor(private router: Router,public userService:UserService,public userFollow:FollowRequestService,public authService:AuthService) {

  }

 ngOnInit() {
   this.userService.getUsers().subscribe(response => this.users = response);
   if(this.authService.isLoggedin==false)
      this.router.navigate(['/']);
   
 }

 onFollow(i:User){
  
    //this.submitted = true;
    console.log(i.user_name);
    console.log(i.id);
    
  this.followingId=i.id;
    let userf = new Follow(this.userService.userId,this.followingId);
    this.userFollow.create(userf)
    .subscribe(data => console.log(data), error => console.log(error));
    console.log(i.id);
    console.log(userf);
   // this.userService.username=this.user_name;
   
      this.router.navigate(['following']);
  
  }

}


