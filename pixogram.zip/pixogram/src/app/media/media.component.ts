import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { AuthService } from '../auth.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-media',
  templateUrl: './media.component.html',
  styleUrls: ['./media.component.css']
})
export class MediaComponent implements OnInit {

  constructor(public userService:UserService,public authService:AuthService,public router:Router) { 
 }

  ngOnInit() {
    if(!this.authService.isLoggedin)
    {
      this.router.navigate(['/']);
    }
  

  }

}
