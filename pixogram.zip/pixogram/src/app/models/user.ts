
export class User{
    public id:number;
    
    constructor(
            public first_name:String,
            public last_name:String,
            public user_name:String,
            public email:String,
            public password:String,
           
           
        ) {
    }  
}