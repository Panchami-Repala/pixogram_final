export class Follow{
    public id1:number;
    
    constructor(
            public userId:number,
            public followingId:number
    ){}
}