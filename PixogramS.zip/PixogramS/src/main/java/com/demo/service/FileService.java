package com.demo.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class FileService {

	
	private static final String FILE_DIRECTORY = "/src";
	 
	public void storeFile(File file) throws IOException {
		Path filePath =  Paths.get(FILE_DIRECTORY + "/" + ((MultipartFile) file).getOriginalFilename());
 
		Files.copy(((MultipartFile) file).getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
		
		
		
	}
	
}
